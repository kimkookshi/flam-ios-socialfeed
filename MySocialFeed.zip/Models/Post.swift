import Foundation

struct Post: Identifiable {
    let id = UUID()
    let user: User
    let content: String
    let imageName: String?
    let time: String
}