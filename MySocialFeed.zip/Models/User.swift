import Foundation

struct User {
    let name: String
    let profileImage: String
}