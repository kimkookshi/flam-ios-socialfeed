import SwiftUI

@main
struct MySocialFeedApp: App {
    var body: some Scene {
        WindowGroup {
            FeedView()
        }
    }
}