import Foundation

struct DummyDataProvider {
    static func getPosts() -> [Post] {
        let user1 = User(name: "Sreeranjini", profileImage: "profile1")
        let user2 = User(name: "Riya Sharma", profileImage: "profile2")

        return [
            Post(user: user1, content: "Enjoying some me-time with Netflix and ice cream 🍦", imageName: "post1", time: "1h ago"),
            Post(user: user2, content: "Weekend getaway 🌊🏝️", imageName: "post2", time: "3h ago"),
            Post(user: user1, content: "Late night coding hits different 💻☕", imageName: nil, time: "6h ago")
        ]
    }
}