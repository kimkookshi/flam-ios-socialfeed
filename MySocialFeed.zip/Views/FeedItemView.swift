import SwiftUI

struct FeedItemView: View {
    let post: Post

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Image(post.user.profileImage)
                    .resizable()
                    .frame(width: 40, height: 40)
                    .clipShape(Circle())

                VStack(alignment: .leading) {
                    Text(post.user.name)
                        .font(.headline)
                    Text(post.time)
                        .font(.caption)
                        .foregroundColor(.gray)
                }
            }

            Text(post.content)
                .font(.body)

            if let imageName = post.imageName {
                Image(imageName)
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                    .frame(height: 200)
                    .clipped()
                    .cornerRadius(10)
            }

            Divider()
        }
        .padding()
    }
}