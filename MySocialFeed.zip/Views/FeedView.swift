import SwiftUI

struct FeedView: View {
    @ObservedObject var viewModel = FeedViewModel()

    var body: some View {
        NavigationView {
            List {
                ForEach(viewModel.posts) { post in
                    FeedItemView(post: post)
                        .listRowInsets(EdgeInsets())
                }
            }
            .navigationTitle("My Feed ✨")
            .refreshable {
                viewModel.refresh()
            }
        }
    }
}